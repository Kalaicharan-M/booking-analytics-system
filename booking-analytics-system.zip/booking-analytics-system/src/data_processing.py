import pandas as pd

def load_and_clean_data():
    # Using raw string (r prefix) to handle Windows paths
    filepath = r"D:\booking-analytics-system\data\hotel_bookings.csv"
    
    df = pd.read_csv(filepath)
    df = df.copy()
    # Handle missing values
    df['country'] = df['country'].fillna('Unknown')
    df['children'] = df['children'].fillna(0)
    
    # Convert dates
    df['reservation_status_date'] = pd.to_datetime(df['reservation_status_date'])
    
    # Calculate total nights
    df['total_nights'] = df['stays_in_weekend_nights'] + df['stays_in_week_nights']
    
    return df