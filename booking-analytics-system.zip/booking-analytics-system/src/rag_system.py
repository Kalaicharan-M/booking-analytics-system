from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import pandas as pd

class RAGSystem:
    def __init__(self, df):
        self.df = df
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.index = faiss.IndexFlatL2(384)
        self._build_index()

    def _build_index(self):
        embeddings = self.model.encode(
            self.df.astype(str).apply(lambda x: ' | '.join(x), axis=1).tolist()
        )
        self.index.add(np.array(embeddings).astype('float32'))

    def query(self, question, k=3):
        query_embedding = self.model.encode(question)
        _, indices = self.index.search(np.array([query_embedding]).astype('float32'), k)
        return self.df.iloc[indices[0].tolist()]