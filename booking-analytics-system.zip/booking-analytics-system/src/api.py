from fastapi import FastAPI
from fastapi.responses import JSONResponse
from src.data_processing import load_and_clean_data
from src.analytics import AnalyticsEngine
from src.rag_system import RAGSystem
from models.llm_setup import BookingQA
import pandas as pd

app = FastAPI()
df = load_and_clean_data()
analytics_engine = AnalyticsEngine(df)
rag_system = RAGSystem(df[['hotel', 'is_canceled', 'country', 'adr', 'lead_time']])
qa_model = BookingQA()
app.get("/")
def read_root():
    return {"message": "Hello, FastAPI!"}
@app.post("/analytics")
async def get_analytics():
    return JSONResponse({
        "revenue_trend": analytics_engine.generate_revenue_trend(),
        "cancellation_rate": analytics_engine.cancellation_rate(),
        "top_countries": analytics_engine.geographical_distribution(),
        "lead_time_analysis": analytics_engine.lead_time_analysis()
    })

@app.post("/ask")
async def ask_question(question: str):
    context_df = rag_system.query(question)
    context = context_df.to_string()
    answer = qa_model.answer_question(context, question)
    
    return JSONResponse({
        "context": context_df.to_dict(),
        "answer": answer
    })

@app.get("/health")
async def health_check():
    return {"status": "healthy", "components": {
        "database": "connected",
        "model": "loaded",
        "rag_system": "ready"
    }}