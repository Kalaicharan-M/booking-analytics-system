import pandas as pd
import matplotlib.pyplot as plt
import base64
from io import BytesIO

class AnalyticsEngine:
    def __init__(self, df):
        self.df = df
        
    def generate_revenue_trend(self):
        revenue_df = self.df.groupby('arrival_date_year')['adr'].sum().reset_index()
        return self._plot_to_base64(revenue_df.plot(x='arrival_date_year', y='adr'))

    def cancellation_rate(self):
        total = len(self.df)
        cancelled = self.df['is_canceled'].sum()
        return (cancelled/total)*100

    def geographical_distribution(self):
        return self.df['country'].value_counts().head(10).to_dict()

    def lead_time_analysis(self):
        plt.hist(self.df['lead_time'], bins=20)
        return self._plot_to_base64(plt)

    def _plot_to_base64(self, plot):
        buffer = BytesIO()
        plot.get_figure().savefig(buffer, format='png')
        buffer.seek(0)
        return base64.b64encode(buffer.read()).decode()